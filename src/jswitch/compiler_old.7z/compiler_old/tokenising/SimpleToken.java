package jswitch.compiler_old.tokenising;

import static jswitch.compiler_old.tokenising.TokenType.SIMPLE;

public class SimpleToken extends Token {

	public SimpleToken(String raw, int mLine, int mColumnStart, int mColumnEnd) {
		super(raw, mLine, mColumnStart, mColumnEnd);
	}

	@Override
	public TokenType getType() {
		return SIMPLE;
	}

}
