package jswitch.compiler_old;

public class JSWitchCompiler {
}
