package jswitch.compiler_old.swil;

public class WordSize {
	
	public int number;
	public WordSizeType inType;
	public boolean isBigEndian;
	
}
