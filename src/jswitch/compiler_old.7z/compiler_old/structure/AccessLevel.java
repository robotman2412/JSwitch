package jswitch.compiler_old.structure;

public enum AccessLevel {
	PUBLIC,
	PROTECTED,
	PACKAGE,
	PRIVATE
}
