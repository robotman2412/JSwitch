package jswitch.compiler_old.structure;

import jswitch.compiler_old.tokenising.Token;

public class Structure {

	protected Token[] tokens;

	protected Structure() {

	}

	public Structure(Token[] mTokens) {
		tokens = mTokens;
	}

	public Token[] getTokens() {
		return tokens.clone();
	}

}
