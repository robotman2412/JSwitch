package jswitch.compiler_old.structure.expression;

import jswitch.compiler_old.CompilerWarning;
import jswitch.compiler_old.SyntaxError;
import jswitch.compiler_old.structure.declarators.DeclaratorStructure;
import jswitch.compiler_old.structure.expression.operators.Operator;
import jswitch.compiler_old.structure.expression.operators.Operators;
import jswitch.compiler_old.tokenising.LiteralToken;
import jswitch.compiler_old.tokenising.StructureToken;
import jswitch.compiler_old.tokenising.Token;
import jswitch.compiler_old.typedef.TypeDef;
import jswitch.util.ListFeeder;

import java.util.*;

public class ExpressionPart {

	public ExpressionPartType type;
	public List<Token> tokens;
	public Operator operator;
	public List<ExpressionPart> subParts;
	public Object value;
	public TypeDef valueType;
	
	public static List<ExpressionPart> rawList(List<Token> filteredTokens) {
		List<ExpressionPart> out = new ArrayList<>();
		for (Token token : filteredTokens) {
			ExpressionPart expr = new ExpressionPart();
			expr.tokens = Collections.singletonList(token);
			if (token instanceof StructureToken) {
				StructureToken s = (StructureToken) token;
				switch (s.getStructureType()) {
					default:
						throw new IllegalArgumentException("Unexpected structure token type: " + s.getStructureType().getName());
					case ARRAY_OPEN:
						expr.type = ExpressionPartType.ARRAY_OPEN;
						break;
					case ARRAY_CLOSE:
						expr.type = ExpressionPartType.ARRAY_CLOSE;
						break;
					case PARENTHESIS_OPEN:
						expr.type = ExpressionPartType.PARENTHESIS_OPEN;
						break;
					case PARENTHESIS_CLOSE:
						expr.type = ExpressionPartType.PARENTHESIS_CLOSE;
						break;
					
				}
			}
			else if (token instanceof LiteralToken) {
				expr.type = ExpressionPartType.LITERAL;
				LiteralToken literal = (LiteralToken) token;
				expr.value = literal.getValue();
				expr.valueType = literal.getAssociatedTypeDef();
			}
			else
			{
				expr.type = ExpressionPartType.RAW;
			}
			out.add(expr);
		}
		return out;
	}
	
	/**
	 * Finds all the references and parses expressions needed to find them.
	 * @param warnings the warnings output
	 * @param syntaxErrors the syntax errors output
	 */
	public void prepReferences(List<CompilerWarning> warnings, List<SyntaxError> syntaxErrors) {
		List<ExpressionPart> reference = new LinkedList<>();
		List<ExpressionPart> newParts = new LinkedList<>();
		for (ExpressionPart part : subParts) {
			if (part.type == ExpressionPartType.RAW) {
				String raw = part.getRawTokens();
				if (raw.equals(",")) {
					//end the reference
				}
				else if (DeclaratorStructure.isNameValid(raw)) {
					reference.add(part);
				}
				else if (raw.equals(".")) {
					reference.add(part);
				}
			}
		}
	}
	
	public void parse(List<CompilerWarning> warnings, List<SyntaxError> syntaxErrors) {
		prepReferences(warnings, syntaxErrors);
		int depth;
		ListFeeder<ExpressionPart> feeder;
		if (subParts.get(0).type == ExpressionPartType.PARENTHESIS_OPEN && subParts.get(subParts.size() - 1).type == ExpressionPartType.PARENTHESIS_CLOSE) {
			feeder = new ListFeeder<>(subParts.subList(1, tokens.size() - 1));
		}
		else {
			feeder = new ListFeeder<>(subParts);
		}
		List<ExpressionPart> newParts = new ArrayList<>();
		//region parenthesies
		while (feeder.length() > 0) {
			ExpressionPart part = feeder.getOne();
			if (part.type == ExpressionPartType.PARENTHESIS_CLOSE) {
				newParts.add(part);
				syntaxErrors.add(new SyntaxError("Closing parenthesis unexpected here.", part.tokens.toArray(new Token[0])));
			}
			else if (part.type == ExpressionPartType.PARENTHESIS_OPEN) {
				ExpressionPart expr = new ExpressionPart();
				expr.subParts = new ArrayList<>();
				expr.tokens = new ArrayList<>();
				expr.type = ExpressionPartType.EXPRESSION;
				newParts.add(expr);
				depth = 1;
				while (true) {
					if (feeder.length() == 0) {
						syntaxErrors.add(new SyntaxError("Closing parenthesis expected here.", tokens.toArray(new Token[0])));
						return;
					}
					ExpressionPart anotherOne = feeder.getOne();
					if (anotherOne.type == ExpressionPartType.PARENTHESIS_CLOSE) {
						depth --;
						if (depth == 0) {
							expr.recalcTokens();
							break;
						}
					}
					else {
						if (anotherOne.type == ExpressionPartType.PARENTHESIS_OPEN) {
							depth++;
						}
						expr.subParts.add(anotherOne);
					}
				}
			}
			else
			{
				newParts.add(part);
			}
		}
		
		subParts = newParts;
		if (syntaxErrors.size() != 0) {
			return;
		}
		
		for (ExpressionPart part : subParts) {
			if (part.type == ExpressionPartType.EXPRESSION) {
				part.parse(warnings, syntaxErrors);
			}
		}
		//endregion parenthesies
		//TODO: pre/post increment/decrement
		//or not, because it makes bugs
		
		//region unary
		newParts = new ArrayList<>();
		Collections.reverse(subParts);
		feeder = new ListFeeder<>(subParts);
		ExpressionPart prev = null;
		while (feeder.hasNext()) {
			ExpressionPart part = feeder.getOne();
			if (part.getRawTokens().equals("-")) {
				if (prev != null && prev.type == ExpressionPartType.LITERAL) {
					ExpressionPart expr = new ExpressionPart();
					expr.type = ExpressionPartType.LITERAL;
					expr.subParts = Arrays.asList(part, prev);
					expr.valueType = prev.valueType;
					if (feeder.hasNext()) {
						ExpressionPart next = feeder.getOne();
						feeder.goBackOne(); //just a preview :)
						if (next.type != ExpressionPartType.OPERATOR && next.type != ExpressionPartType.CAST) {
							newParts.add(part);
							continue; //unary does not apply with anything except operator or cast before it
						}
					}
					if (Operators.SUBTRACT.appliesUnary(expr.valueType) != null) {
						expr.value = Operators.SUBTRACT.resolveUnary(prev.valueType, prev.value);
					} else {
						expr.value = prev.value;
						syntaxErrors.add(new SyntaxError("Unary operator does not apply to type: " + expr.valueType.getTypeNames()[0], expr.tokens.get(0)));
					}
					newParts.add(expr);
				}
			}
			else
			{
				newParts.add(part);
			}
			prev = part;
		}
		
		Collections.reverse(newParts);
		subParts = newParts;
		//endregion unary
		
		//region multiplicative
		newParts = new ArrayList<>();
		feeder = new ListFeeder<>(subParts);
		prev = null;
		while (feeder.hasNext()) {
			ExpressionPart part = feeder.getOne();
			if (part.getRawTokens().equals("*")) {
				if (!feeder.hasNext()) {
					syntaxErrors.add(new SyntaxError("Expression seems unfinished, missing right hand side.", part.tokens.toArray(new Token[0])));
					return;
				}
				ExpressionPart next = feeder.getOne();
				
			}
			else if (part.getRawTokens().equals("/")) {
				if (!feeder.hasNext()) {
					syntaxErrors.add(new SyntaxError("Expression seems unfinished, missing right hand side.", part.tokens.toArray(new Token[0])));
					return;
				}
				ExpressionPart next = feeder.getOne();
				
			}
		}
		
		subParts = newParts;
		//endregion multiplicative
		
		//region additive
		//endregion additive
	}
	
	private void recalcTokens() {
		tokens = new ArrayList<>();
		for (ExpressionPart part : subParts) {
			tokens.addAll(part.tokens);
		}
	}
	
	public String getRawTokens() {
		String s = "";
		for (Token token : tokens) {
			s += token.getRawContent();
		}
		return s;
	}
	
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder(type + ": ");
		if (subParts == null || subParts.size() == 0) {
			for (Token token : tokens) {
				s.append(token.getRawContent());
			}
		}
		else {
			s.append("{\n");
			for (ExpressionPart part : subParts) {
				String[] split = part.toString().split("\n");
				for (String split0 : split) {
					s.append("  ").append(split0).append("\n");
				}
			}
			s.append("}");
		}
		return s.toString();
	}
}
