package jswitch.compiler_old.structure.expression;

public enum ExpressionPartType {
	
	PARENTHESIS_OPEN,
	PARENTHESIS_CLOSE,
	ARRAY_OPEN,
	ARRAY_CLOSE,
	EXPRESSION,
	CAST,
	OPERATOR,
	REFERENCE,
	RAW,
	LITERAL
	
}
