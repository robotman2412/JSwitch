package jswitch.compiler_old.structure.expression;

import jswitch.compiler_old.CompilerFeedback;

public class ExpressionOut {
	
	public ExpressionStructure expression;
	public CompilerFeedback feedback;
	
	public ExpressionOut(ExpressionStructure mExpression, CompilerFeedback mFeedback) {
		expression = mExpression;
		feedback = mFeedback;
	}
	
}
