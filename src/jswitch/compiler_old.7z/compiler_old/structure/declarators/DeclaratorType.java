package jswitch.compiler_old.structure.declarators;

public enum DeclaratorType {
	CLASS,
	METHOD,
	INTERFACE,
	ANNOTATION,
	ENUM,
	VARIABLE
}
