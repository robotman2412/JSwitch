package jswitch.compiler_old.structure.declarators;

import jswitch.compiler_old.CompilerFeedback;

public class DeclaratorOut {

	public DeclaratorStructure declarator;
	public CompilerFeedback feedback;

	public DeclaratorOut(DeclaratorStructure mDeclarator, CompilerFeedback mFeedback) {
		declarator = mDeclarator;
		feedback = mFeedback;
	}

}
